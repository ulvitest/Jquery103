$(document).ready(function(){

// let allLi= $("ul li");
// console.log(allLi);

$("button").click(function(){
    $("p").show();
})
$("p").mouseenter(function(){
    //alert("p uzeri");
})

$("p").mouseleave(function(){
    //alert("p leave");
})

$("input").keyup(function(){
   //console.log($("input").val());
})

$(".main").click(function(){
    // $(".test").fadeOut(5000,function(){
    //     alert();
    // })
    //$(".test").slideToggle(3000);

    // $(".test").animate({
    //     "margin-top":"100px",
    
    // },3000,function(){
    //     $("p").show()
    // })
    // $(".test").css({
    //     "margin-top":"200px",
    //     "background-color":"green"
    // })
    //$(".test").css("background-color","green").animate({"margin-top":"100px"},3000)
    //$("p").html("<h1>Lorem</h1>");
    //$(".test").removeClass("custom")
    console.log($(".test").height());
})


// $(".main").click(function(){
//     alert("override")
// })

// $(".main").click(function(){
//     alert("override1")
// })




})


